<div id="fh5co-header">
			<header id="fh5co-header-section">
				<div class="container">
					<div class="nav-header">
						<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
						<h1 id="fh5co-logo"><a href="index.html">Say-yes</a></h1>
						<!-- START #fh5co-menu-wrap -->
						<nav id="fh5co-menu-wrap" role="navigation">
							<ul class="sf-menu" id="fh5co-primary-menu">
								<li class="active">
									<a href="index.php">Home</a>
								</li>
								<li>
									<a href="listing.php" class="fh5co-sub-ddown">Countries</a>
									<ul class="fh5co-sub-menu">
										<li><a href="http://freehtml5.co/preview/?item=build-free-html5-bootstrap-template" target="_blank">France</a></li>
										<li><a href="http://freehtml5.co/preview/?item=work-free-html5-template-bootstrap" target="_blank">England</a></li>
										<li><a href="http://freehtml5.co/preview/?item=light-free-html5-template-bootstrap" target="_blank">Germany</a></li>
										<li><a href="http://freehtml5.co/preview/?item=relic-free-html5-template-using-bootstrap" target="_blank">USA</a></li>
										<li><a href="http://freehtml5.co/preview/?item=display-free-html5-template-using-bootstrap" target="_blank">Spain</a></li>
										<li style="background-color: #83CC61;"><a href="listing.php"> <font color="white">See More</font></a></li>
									</ul>
								</li>

								<li><a href="contact.php">About Us</a></li>

								<li class="btn btn-primary btn-lg" style="background-color: #83CC61;">
									<a href="index.php"  target="_blank"><font color="white" size="3,6px">Add Your Place</font></a>
								</li>

							</ul>
						</nav>
					</div>
				</div>
			</header>
			
		</div>